# AMEX Partner Offers — 本地运行说明

这是已展示页面的完整前端源码和图片资源。使用原生 HTML、CSS、JavaScript；没有构建步骤、npm 依赖、数据库或 API Key。普通现代浏览器即可运行。

## 1. 本地启动

先解压 ZIP，再进入包含 `index.html` 的 `amex-partner-offers-source` 文件夹。以下方式需要电脑已安装 Python 3。

### macOS / Linux

在终端中执行（`cd` 后的路径需对应解压位置）：

```bash
cd amex-partner-offers-source
python3 -m http.server 8000 --bind 127.0.0.1
```

### Windows

在 PowerShell 中执行（`cd` 后的路径需对应解压位置）：

```powershell
cd amex-partner-offers-source
py -3 -m http.server 8000 --bind 127.0.0.1
```

如果 Windows 没有 `py` 命令，但 `python --version` 显示 Python 3，可以改用：

```powershell
python -m http.server 8000 --bind 127.0.0.1
```

打开浏览器，访问：

<http://127.0.0.1:8000>

运行期间保持终端打开。停止服务：在终端按 `Ctrl+C`。

如果 8000 端口被占用，把命令中的 `8000` 改为 `8001`，并访问 `http://127.0.0.1:8001`。

此命令仅监听本机，不会公开到互联网，也不供同一 Wi-Fi 下的其他设备访问。这里的 HTTP 服务用于本地预览，不是生产服务器。

也可以直接双击 `index.html` 快速查看；正式演示建议使用上面的本地 HTTP 方式。所有页面资源均在压缩包内，启动后不需要外部 API 或图片服务。

## 2. 文件结构

| 文件 | 用途 |
| --- | --- |
| `index.html` | 页面结构、标题、控件容器、对话框入口 |
| `styles.css` | AMEX 蓝色主题、旅行氛围、卡片和手机布局 |
| `app.js` | 行业及 offer 数据、推荐切换、金额展示、接受/修改/拒绝流程 |
| `assets/travel-hero.webp` | 随包提供的旅行背景图 |
| `README.md` | 本文档 |

目录名 `dist` 没有打入导出包；原来的三个前端文件直接放在本包根目录，图片相对路径保持不变。

## 3. 如何演示

1. 右上角 `DEMO WORKSPACE` 切换酒店、航空公司或餐饮商户。
2. 在 `Your priority` 中选择增长、收益或高端礼遇，主推荐随之切换。
3. 点击备选方案的 `View option`，比较对应的销售额、成本和新增收益。
4. 点击 `How these estimates work`，查看无活动基准、贡献毛利假设及计算过程。
5. 点击 `Review & accept offer`，查看预算与条款，勾选后确认演示接受。
6. 也可以 `Request changes` 或 `Decline offer`；页面会展示状态，并支持 `Undo`。
7. 页底 `Reset demo` 回到初始状态。

## 4. 修改数据和样式

### 修改商户与 offer

在 `app.js` 中搜索 `baseOffers`。其中有三个演示行业：

- `hotel`：Harbour Hotel。
- `airline`：Aster Airways。
- `dining`：Maison Table。

每个行业包含 `growth`、`earnings`、`premium` 三类方案。

关键字段：

| 字段 | 含义 |
| --- | --- |
| `baseline` | 不开展活动时的预计销售额 |
| `margin` | 扣除可变经营成本后的贡献毛利率，例如 `0.5` |
| `offers.<方案>.sales` | 相对无活动基准的新增销售额，不是总销售额 |
| `offers.<方案>.cost` | 商户预计承担的活动成本 |
| `offers.<方案>.cap` | 商户预算上限，不是额外再加一笔成本 |
| `offers.<方案>.limit` | 活动兑换数量上限 |
| `fundingText` | 每次兑换的商户出资说明 |
| `headline` / `description` / `customer` | 页面标题、方案说明、顾客获得的优惠 |
| `why` / `condition` | 推荐理由与适用条款 |

当前页面计算：

```text
预计总销售额 = baseline + sales
预计新增收益 = sales × margin − cost
```

“新增收益”指扣除可变成本和商户 offer 成本后的增量贡献，未扣除固定成本，不等于商户总净利润。修改优惠金额时，也要同步检查 `fundingText`、预算、数量上限、预测成本、条件和顾客文案是否一致。

### 修改页面外观

- `styles.css` 顶部 `:root`：主要颜色。
- `.hero`、`.hero-image`：顶部背景及高度。
- `.proposal`：主推荐卡片布局。
- `@media`：手机、平板和桌面适配。
- 替换 `assets/travel-hero.webp`：更换背景图；保持文件名即可。

编辑后保存并刷新浏览器。如浏览器仍显示旧样式，执行强制刷新。

## 5. 当前实现边界

- 这是前端交互原型，所有商户、商业条款和预测数字均为演示数据。
- 推荐切换读取预设方案，没有调用真实 AI、预测模型或 AMEX 系统。
- 接受、拒绝和修改请求只记录在当前页面内存中；刷新、关闭页面后会清空。
- 不会发送消息、扣费或创建真实活动。
- AMEX 自身收入、长期客户价值和补贴回报没有在商家页面中展示，也没有接入真实计算。
- `app.js` 对可选的 `document.modelContext` 做了能力检测；普通浏览器不支持时会自动跳过，不影响页面运行。
- 本地包无需原在线页面的登录和访问权限；不要把它视为包含身份认证的生产应用。

未来若连接后端，可保留现有 UI，将 `baseOffers` 替换为 API 返回的数据，并让接受、修改、拒绝动作提交到对应接口。
